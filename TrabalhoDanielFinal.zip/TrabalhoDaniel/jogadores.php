<?php
//Exibir erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once("util/Conexao.php");

$conexao = Conexao::getConexao();
//print_r($conexao);

$msgErro = "";
$nome = "";
$clube = "";
$numero = "";
$posicao = "";
$liga = "";
$valor = "";
$img = "";

//Salvar o livro
if (isset($_POST['nome'])) {
    //1- Receber os dados do formulário
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : null;
    $clube = trim($_POST['clube']) ? trim($_POST['clube']) : null;
    $posicao = trim($_POST['posicao']) ? trim($_POST['posicao']) : null;
    $numero = is_numeric($_POST['numero']) ? ($_POST['numero']) : null;
    $liga = trim($_POST['liga']) ? trim($_POST['liga']) : null;
    $valor = trim($_POST['valor']) ? trim($_POST['valor']) : null;
    $img = trim($_POST['img']) ? trim($_POST['img']) : null;

    //1.1 - Validar os dados
    $msgs = array();
    if (! $nome)
        array_push($msgs, "Informe o nome do atleta!");
    else if (strlen($nome) < 3)
        array_push($msgs, "Insira um nome válido");


    if (! $nome)
        array_push($msgs, "Informe o nome do jogaodor!");

    if (! $clube)
        array_push($msgs, "Informe o clube!");

    if ($posicao == null || $posicao == "")
        array_push($msgs, "Informe a posição do jogador!");


    if (! $numero)
        array_push($msgs, "Informe o numero da camisa!");
    else if ($numero <= 0 || $numero > 99)
        array_push($msgs, "O número de páginas deve ser maior que 0 e menor que 100!");


    if ($liga == null || $liga == "")
        array_push($msgs, "Informe a liga do jogador!");

    if (! $valor)
        array_push($msgs, "Informe o valor do jogador!");

    if ($img == null || $img == "")
        array_push($msgs, "Informe uma imagem");

    if (empty($msgs)) {
        //2- Inserir o jogador no banco de dados
        $sql = "INSERT INTO jogadores (nome, clube, posicao, numero, liga, valor, img)
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stm = $conexao->prepare($sql);
        $stm->execute([$nome, $clube, $posicao, $numero, $liga, $valor, $img,]);

        //3- Redirecionar para a página de listagem
        header("location: jogadores.php");
    } else {
        //Exibir as mensagens de erro
        $msgErro = implode("<br>", $msgs);
    }
}

//Listagem dos livros
$sql = "SELECT * FROM jogadores";
$stm = $conexao->prepare($sql);
$stm->execute();
$jogadores = $stm->fetchAll();

//echo "<pre>" . print_r($jogadores, true) . "</pre>";

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Jogadores</title>
</head>
<style>
    body {
        background-color: #b8d2f8;
        font-family: Arial, Helvetica, sans-serif;
        margin: 20px;
    }

    .box {
        background: white;
        max-width: 1000px;
        margin: auto;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    h1,
    h3 {
        color: #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    table th {
        background-color: #009a1c;
        color: white;
        padding: 12px;
        text-align: left;
    }

    table td {
        padding: 10px;
        border-bottom: 1px solid #ddd;
    }

    table tr:nth-child(even) {
        background-color: #f8f9fa;
    }

    table tr:hover {
        background-color: #e8f4ff;
    }

    input,
    select {
        width: 100%;
        max-width: 400px;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 6px;
    }

    button {
        background-color: #28a745;
        color: white;
        border: none;
        padding: 10px 18px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 15px;
    }

    button:hover {
        background-color: #218838;
    }
</style>

<body>
    <div class="box">
        <h1>Cadastro de Jogadores</h1>

        <h3>Listagem</h3>

        <table border="1">
            <!-- Cabeçalho -->
            <div class="cabecalho">
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Posição</th>
                    <th>Numero</th>
                    <th>Clube</th>
                    <th>Liga</th>
                    <th>Valor $</th>
                    <th>Excluir</th>

                </tr>
            </div>

            <!-- Dados -->
            <?php foreach ($jogadores as $j): ?>
                <tr>
                    <td><?= $j["id"] ?></td>
                    <td><?= $j["nome"] ?></td>
                    <td>
                        <?php
                        if ($j['posicao'] == 'ATA')
                            echo "Atacante";
                        else if ($j['posicao'] == 'MC')
                            echo "Meio-Campo";
                        else if ($j['posicao'] == 'VOL')
                            echo "Volante";
                        else if ($j['posicao'] == 'ZAG')
                            echo "Zagueiro";
                        else if ($j['posicao'] == 'GK')
                            echo "Goleiro";
                        ?>
                    </td>

                    <td><?= $j["numero"] ?></td>
                    <td><?= $j["clube"] ?></td>
                    <td><?php
                        if ($j['liga'] == 'BR')
                            echo "Brasileirão";
                        else if ($j['liga'] == 'LO')
                            echo "Ligue-One";
                        else if ($j['liga'] == 'PL')
                            echo "Premier-League";
                        else if ($j['liga'] == 'LL')
                            echo "Laliga";
                        else if ($j['liga'] == 'BL') {
                            echo "Bundesliga";
                        }

                        ?>
                    </td>
                    <td><?= $j["valor"] ?></td>
                    <td>
                        <a href="excluirJogador.php?id=<?= $j['id'] ?>"
                        onclick="if(! confirm('Confirma a exclusão?')) return false;">Excluir</a>
                    </td>
                </tr>

            <?php endforeach; ?>
        </table>


        <h3>Formulário</h3>

        <!-- form action="" method="POST" onsubmit="return validarForm();" -->
        <form action="" method="POST">

            <input type="text" placeholder="Informe o nome do jogador"
                name="nome" id="nome"
                value="<?= $nome ?>">

            <br><br>

            <input type="text" placeholder="Informe o clube"
                name="clube" id="clube"
                value="<?= $clube ?>">

            <br><br>

            <select name="posicao" id="posicao">
                <option value="">---Selecione a posição---</option>
                <option value="ATA" <?= $posicao == "ATA" ? "selected" : "" ?>>
                    Atacante</option>
                <option value="MC" <?= $posicao == "MC" ? "selected" : "" ?>>
                    Meio-Campo</option>
                <option value="VOL" <?= $posicao == "VOL" ? "selected" : "" ?>>
                    Volante</option>
                <option value="ZAG" <?= $posicao == "ZAG" ? "selected" : "" ?>>
                    Zagueiro</option>
                <option value="GK" <?= $posicao == "GK" ? "selected" : "" ?>>
                    Goleiro</option>
            </select>

            <br><br>

            <input type="number" name="numero" id="numero"
                placeholder="Informe o número da camisa"
                value="<?= $numero ?>">

            <br><br>

            <select name="liga" id="liga">
                <option value="">---Selecione a liga---</option>
                <option value="BR" <?= $liga == "BR" ? "selected" : "" ?>>
                    Brasileirão</option>
                <option value="LO" <?= $liga == "LO" ? "selected" : "" ?>>
                    Ligue-One</option>
                <option value="PL" <?= $liga == "PL" ? "selected" : "" ?>>
                    Premier-League</option>
                <option value="LL" <?= $liga == "LL" ? "selected" : "" ?>>
                    Laliga</option>
                <option value="BL" <?= $liga == "BL" ? "selected" : "" ?>>
                    Bundesliga</option>
            </select>
            <br><br>

            <input type="number" name="valor" id="valor"
                placeholder="Informe o valor do jogador (em euros)"
                value="<?= $valor ?>">
                <br><br>

            <input type="text" placeholder="Informe a imagem do Jogador"
                name="img" id="img"
                value="<?= $img ?>">

            <br><br>

            <button>Gravar</button>
            <button><a href="jogadorCard.php">Ver Cards</a></button>
        </form>


        <div style="color: red;">
            <?= $msgErro ?>
        </div>


    </div>
</body>

</html>