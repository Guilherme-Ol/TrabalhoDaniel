<?php

require_once("util/Conexao.php");




$conexao = Conexao::getConexao();

$sql = "SELECT * FROM jogadores";
$stm = $conexao->prepare($sql);
$stm->execute();

$jogadores = $stm->fetchAll();

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<style>
    body{
        background-color: #dbffbb;
    }
    h1{
        display: flex;
        justify-content: center;
    }
    .container{
        display: flex;
        justify-content: center;
    }
    .card {
        width: 250px;
        height: 400px;
        background: linear-gradient(178deg, green, #ffea00);
        border-radius: 20px;
        padding: 10px;
        color: black;
        position: relative;
        text-align: center;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
        margin: 15px;
    }

    .nome {
        margin-top: 15px;
        font-size: 22px;
        font-weight: bold;
        color: #1eff00;
    }

    .numero {
        position: absolute;
        top: 300px;
        left: 210px;
        font-size: 30px;
        font-weight: bold;
        color: green;
    }

    .posicao {
        position: absolute;
        top: 100px;
        left: 20px;
        font-size: 18px;
        font-weight: bold;
        color: yellow;
    }

    .liga {
        position: absolute;
        top: 360px;
        left: 10px;
        font-size: 18px;
        font-weight: bold;
        color: green;

    }

    .img {
        width: 250px;
        height: 300px;
        display: flex;
        justify-content: center;
    }

    .voltar {


        display: block;
        width: 120px;
        margin: 20px auto;
        text-align: center;
        padding: 10px;
        background-color: #005eff;
        color: white;
        text-decoration: none;
        border-radius: 8px;
    }

    .voltar:hover {
        background-color: #0044bb;
    }
</style>

<body>



    
    <h1>Jogadores</h1>
    <div class="container">

        <?php foreach ($jogadores as $j): ?>

            <div class="card">

                <div class="nome">
                    <h2><?= $j['nome'] ?></h2>
                </div>
                <div class="posicao">
                    <?php
                    if ($j['posicao'] == 'ATA')
                        echo "Atacante";
                    else if ($j['posicao'] == 'MC')
                        echo "Meio-Campo";
                    else if ($j['posicao'] == 'VOL')
                        echo "Volante";
                    else if ($j['posicao'] == 'ZAG')
                        echo "Zagueiro";
                    else if ($j['posicao'] == 'GK')
                        echo "Goleiro";
                    ?>
                </div>

                <div class="img">
                    <img src="<?php echo $j['img']; ?>" alt="">
                </div>

                <div class="numero">
                    <h2><?= $j['numero'] ?></h2>

                </div>



                <div class="liga">
                    <?php
                    if ($j['liga'] == 'BR')
                        echo "Brasileirão";
                    else if ($j['liga'] == 'LO')
                        echo "Ligue-One";
                    else if ($j['liga'] == 'PL')
                        echo "Premier-League";
                    else if ($j['liga'] == 'LL')
                        echo "Laliga";
                    else if ($j['liga'] == 'BL') {
                        echo "Bundesliga";
                    }
                    ?>
                </div>
            
            </div>

        <?php endforeach; ?>
    </div>

    <br><br><br>
    <a href="jogadores.php" class="voltar"> Voltar</a>

</body>

</html>