<?php

require_once("util/Conexao.php");


$id = 0;
if(isset($_GET['id']))
    $id = $_GET['id'];

if($id > 0) {

    $conexao = Conexao::getConexao();
    
    $sql = "DELETE FROM jogadores WHERE id = ?";
    $stm = $conexao->prepare($sql);
    $stm->execute([$id]);

    
    header("location: jogadores.php");

} else {
    echo "Parâmetro ID inválido!<br>";
    echo "<a href='jogadores.php'>Voltar</a>";
}