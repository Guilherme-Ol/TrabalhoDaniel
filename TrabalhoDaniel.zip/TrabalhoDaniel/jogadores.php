<?php
//Exibir erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once("util/Conexao.php");
require_once("modelo/jogadorCard.php");

$conexao = Conexao::getConexao();
//print_r($conexao);

$msgErro = "";

$nome = "";
$clube = "";
$numero = "";
$posicao = "";
$liga = "";
$valor = "";

//Salvar o livro
if (isset($_POST['nome'])) {
    //1- Receber os dados do formulário
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : null;
    $clube = trim($_POST['clube']) ? trim($_POST['clube']) : null;
    $posicao = trim($_POST['posicao']) ? trim($_POST['posicao']) : null;
    $numero = is_numeric($_POST['numero']) ? ($_POST['numero']) : null;
    $liga = trim($_POST['liga']) ? trim($_POST['liga']) : null;
    $valor = trim($_POST['valor']) ? trim($_POST['valor']) : null;

    //1.1 - Validar os dados
    $msgs = array();
    if (! $nome)
        array_push($msgs, "Informe o nome do atleta!");
    else if (strlen($nome) < 3)
        array_push($msgs, "Insira um nome válido");
    /*else {
        //Validação de título repetido
        $sql = "SELECT id FROM livros WHERE titulo = ?";
        $stm = $conexao->prepare($sql);
        $stm->execute([$titulo]);
        $retorno = $stm->fetchAll();

        if(count($retorno) > 0) 
            array_push($msgs, "Este título já foi cadastrado!");
    }*/

    if (! $nome)
        array_push($msgs, "Informe o nome do jogaodor!");

    if (! $clube)
        array_push($msgs, "Informe o clube!");

    if ($posicao == null || $posicao == "")
        array_push($msgs, "Informe a posição do jogador!");

    if (! $numero)
        array_push($msgs, "Informe o numero da camisa!");
    else if ($numero <= 0 || $numero > 99)
        array_push($msgs, "O número de páginas deve ser maior que 0 e menor que 100!");


    if ($liga == null || $liga == "")
        array_push($msgs, "Informe a liga do jogador!");

    if (! $valor)
        array_push($msgs, "Informe o valor do jogador!");


    if (empty($msgs)) {
        //2- Inserir o jogador no banco de dados
        $sql = "INSERT INTO jogadores (nome, clube, posicao, numero, liga, valor)
                VALUES (?, ?, ?, ?, ?, ?)";
        $stm = $conexao->prepare($sql);
        $stm->execute([$nome, $clube, $posicao, $numero, $liga, $valor]);

        //3- Redirecionar para a página de listagem
        header("location: jogadores.php");
    } else {
        //Exibir as mensagens de erro
        $msgErro = implode("<br>", $msgs);
    }
}

//Listagem dos livros
$sql = "SELECT * FROM jogadores";
$stm = $conexao->prepare($sql);
$stm->execute();
$jogadores = $stm->fetchAll();

//echo "<pre>" . print_r($jogadores, true) . "</pre>";

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Jogadores</title>
</head>
<style>
    .box {

        background: #bfbfbf;
        border-color: lightcoral;
        border-radius: 20px;
        padding: 10px;
        color: black;

    }

</style>

<body>
    <div class="box">
        <h1>Cadastro de Jogadores</h1>

        <h3>Listagem</h3>

        <table border="1">
            <!-- Cabeçalho -->
            <div class="cabecalho">
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Posição</th>
                    <th>Numero</th>
                    <th>Clube</th>
                    <th>Liga</th>
                    <th>Valor</th>
                    <th>Excluir</th>

                </tr>
            </div>

            <!-- Dados -->
            <?php foreach ($jogadores as $j): ?>
                <tr>
                    <td><?= $j["id"] ?></td>
                    <td><?= $j["nome"] ?></td>
                    <td>
                        <?php
                        if ($j['posicao'] == 'ATA')
                            echo "Atacante";
                        else if ($j['posicao'] == 'MC')
                            echo "Meio-Campo";
                        else if ($j['posicao'] == 'VOL')
                            echo "Volante";
                        else if ($j['posicao'] == 'ZAG')
                            echo "Zagueiro";
                        else if ($j['posicao'] == 'GK')
                            echo "Goleiro";
                        ?>
                    </td>

                    <td><?= $j["numero"] ?></td>
                    <td><?= $j["clube"] ?></td>
                    <td><?php
                        if ($j['liga'] == 'BR')
                            echo "Brasileirão";
                        else if ($j['liga'] == 'LO')
                            echo "Ligue-One";
                        else if ($j['liga'] == 'PL')
                            echo "Premier-League";
                        else if ($j['liga'] == 'LL')
                            echo "Laliga";
                        else if ($j['liga'] == 'BL') {
                            echo "Bundesliga";
                        }

                        ?>

                    </td>

                    <td><?= $j["valor"] ?></td>
                    <td>
                        <a href="excluirJogador.php?id=<?= $j['id'] ?>"
                            onclick="if(! confirm('Confirma a exclusão?')) return false;">Excluir</a>
                    </td>
                </tr>

            <?php endforeach; ?>
        </table>

       <?= $jogador = new Card();

$jogador->setNome($_POST['nome']);
$jogador->setImg($_POST['img']);
$jogador->setPosicao($_POST['pos']);
$jogador->setPais($_POST['pais']);

?>


        <h3>Formulário</h3>

        <!-- form action="" method="POST" onsubmit="return validarForm();" -->
        <form action="" method="POST">

            <input type="text" placeholder="Informe o nome do jogador"
                name="nome" id="nome"
                value="<?= $nome ?>">

            <br><br>

            <input type="text" placeholder="Informe o clube"
                name="clube" id="clube"
                value="<?= $clube ?>">

            <br><br>

            <select name="posicao" id="posicao">
                <option value="">---Selecione a posição---</option>
                <option value="ATA" <?= $posicao == "ATA" ? "selected" : "" ?>>
                    Atacante</option>
                <option value="MC" <?= $posicao == "MC" ? "selected" : "" ?>>
                    Meio-Campo</option>
                <option value="VOL" <?= $posicao == "VOL" ? "selected" : "" ?>>
                    Volante</option>
                <option value="ZAG" <?= $posicao == "ZAG" ? "selected" : "" ?>>
                    Zagueiro</option>
                <option value="GK" <?= $posicao == "GK" ? "selected" : "" ?>>
                    Goleiro</option>
            </select>

            <br><br>

            <input type="number" name="numero" id="numero"
                placeholder="Informe o número da camisa"
                value="<?= $numero ?>">

            <br><br>

            <select name="liga" id="liga">
                <option value="">---Selecione a liga---</option>
                <option value="BR" <?= $liga == "BR" ? "selected" : "" ?>>
                    Brasileirão</option>
                <option value="LO" <?= $liga == "LO" ? "selected" : "" ?>>
                    Ligue-One</option>
                <option value="PL" <?= $liga == "PL" ? "selected" : "" ?>>
                    Premier-League</option>
                <option value="LL" <?= $liga == "LL" ? "selected" : "" ?>>
                    Laliga</option>
                <option value="BL" <?= $liga == "BL" ? "selected" : "" ?>>
                    Bundesliga</option>
            </select>
            <br><br>

            <input type="number" name="valor" id="valor"
                placeholder="Informe o valor do jogador"
                value="<?= $valor ?>">

            <button>Gravar</button>

        </form>

        <div id="msgErro" style="color: red; display: none;">
            Exemplo de erro!
        </div>

        <div style="color: red;">
            <?= $msgErro ?>
        </div>

        <script src="validacao.js"></script>
    </div>
</body>

</html>