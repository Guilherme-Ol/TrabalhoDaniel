<?php


class Card {

    private $nome;
    private $img;
    private $posicao;



    /**
     * Get the value of nome
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome($nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of img
     */
    public function getImg()
    {
        return $this->img;
    }

    /**
     * Set the value of img
     */
    public function setImg($img): self
    {
        $this->img = $img;

        return $this;
    }

    /**
     * Get the value of posicao
     */
    public function getPosicao()
    {
        return $this->posicao;
    }

    /**
     * Set the value of posicao
     */
    public function setPosicao($posicao): self
    {
        $this->posicao = $posicao;

        return $this;
    }

  
    }
