CREATE TABLE jogadores
(
    id INTEGER NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    clube VARCHAR(50) NOT NULL,
    posicao VARCHAR(3) NOT NULL, /*ATA=Atacante, ZAG=Zagueiro, MC=*/
    numero INTEGER(99) NOT NULL,
    liga VARCHAR(2) NOT NULL,
    valor VARCHAR(50) NOT NULL,
    CONSTRAINT pk_jogador PRIMARY KEY (id) 
);
